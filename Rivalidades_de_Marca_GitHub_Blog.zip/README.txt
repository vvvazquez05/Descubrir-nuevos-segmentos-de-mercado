BLOG LISTO PARA GITHUB PAGES

1. Sube index.html a tu repositorio.
2. En GitHub: Settings > Pages.
3. Source: Deploy from a branch.
4. Branch: main / root.
5. Guarda y espera a que GitHub publique la página.
6. Entrega el enlace que GitHub genere.

No necesitas instalar nada ni modificar el HTML.
